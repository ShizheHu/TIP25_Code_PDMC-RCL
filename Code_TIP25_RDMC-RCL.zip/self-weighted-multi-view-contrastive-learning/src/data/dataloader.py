import numpy as np
from torch.utils.data import Dataset
import torch
import scipy.io
from sklearn.preprocessing import MinMaxScaler

class DatasetNpz(Dataset):
    def __init__(self, name):
        data = np.load('../../dataset/' + f"{name}.npz")
        self.n_views = int(data["n_views"])
        self.labels = data["labels"].reshape(-1, 1)
        # self.labels = data["labels"]
        self.n_clusters = len(np.unique(self.labels))
        self.data_views = []
        self.view_dims = []

        for v in range(self.n_views):
            data_view = data[f"view_{v}"].astype(np.float32)
            self.data_views.append(data_view)
            self.view_dims.append(data_view.shape[1])

        self.data_size = self.data_views[0].shape[0]

    def __len__(self):
        return self.data_size

    def __getitem__(self, idx):
        return [torch.from_numpy(view[idx]) for view in self.data_views], \
            torch.from_numpy(self.labels[idx]), \
            torch.from_numpy(np.array(idx)).long()


class DatasetMat(Dataset):
    def __init__(self, name, n_views):
        data = scipy.io.loadmat('../../dataset/' + f'{name}.mat')
        self.labels = data['Y'].astype(np.float32).reshape(-1, 1)
        self.n_views = n_views
        self.n_clusters = len(np.unique(self.labels))
        self.data_views = []
        self.view_dims = []

        for v in range(self.n_views):
            data_view = data['X'][v][0].astype(np.float32)
            self.data_views.append(data_view)
            self.view_dims.append(data_view.shape[1])

        self.data_size = self.data_views[0].shape[0]

    def __len__(self):
        return self.data_size

    def __getitem__(self, idx):
        return [torch.from_numpy(view[idx]) for view in self.data_views], \
            torch.from_numpy(self.labels[idx]), \
            torch.from_numpy(np.array(idx)).long()


class NUSWIDE(Dataset):
    def __init__(self, view):
        data = scipy.io.loadmat('../../dataset/NUSWIDE.mat')
        self.n_views = view
        self.data_views = []
        self.labels = data['Y'].T
        self.view_dims = []
        self.n_clusters = len(np.unique(self.labels))
        for i in range(view):
            self.data_views.append(data['X' + str(i + 1)][:, :-1].astype(np.float32))
            self.view_dims.append(data['X' + str(i + 1)][:, :-1].shape[1])
        self.data_size = self.data_views[0].shape[0]

    def __len__(self):
        return self.data_size

    def __getitem__(self, idx):
        data_getitem = []
        for i in range(self.n_views):
            data_getitem.append(torch.from_numpy(self.data_views[i][idx]))
        return data_getitem, torch.from_numpy(self.labels[idx]), torch.from_numpy(np.array(idx)).long()



class BDGP(Dataset):
    def __init__(self, view):
        data = scipy.io.loadmat('../../dataset/BDGP.mat')
        self.n_views = view
        self.data_views = []
        self.labels = data['Y'].T
        self.view_dims = []
        self.n_clusters = len(np.unique(self.labels))
        for i in range(view):
            self.data_views.append(data['X' + str(i + 1)].astype(np.float32))
            self.view_dims.append(data['X' + str(i + 1)].shape[1])
        self.data_size = self.data_views[0].shape[0]

    def __len__(self):
        return self.data_size

    def __getitem__(self, idx):
        data_getitem = []
        for i in range(self.n_views):
            data_getitem.append(torch.from_numpy(self.data_views[i][idx]))
        return data_getitem, torch.from_numpy(self.labels[idx]), torch.from_numpy(np.array(idx)).long()

class fashion(Dataset):
    def __init__(self, view):
        data = scipy.io.loadmat('../../dataset/fashion.mat')
        self.n_views = view
        self.data_views = []
        self.labels = data['Y'].T
        self.view_dims = []
        self.n_clusters = len(np.unique(self.labels))
        for i in range(view):
            self.data_views.append(data['X' + str(i + 1)].astype(np.float32))
            self.view_dims.append(data['X' + str(i + 1)].shape[1])
        self.data_size = self.data_views[0].shape[0]

    def __len__(self):
        return self.data_size

    def __getitem__(self, idx):
        data_getitem = []
        for i in range(self.n_views):
            data_getitem.append(torch.from_numpy(self.data_views[i][idx]))
        return data_getitem, torch.from_numpy(self.labels[idx]), torch.from_numpy(np.array(idx)).long()


def load_data(dataset):
    dataset_name = ["Caltech-2V", "Caltech-3V", "Caltech-4V", "Caltech-5V", "Caltech-6V","NUSWIDE-OBJECT"]

    if dataset in dataset_name:
        dataset = DatasetNpz(dataset)
    elif dataset == 'fashion':
        dataset = fashion(view=3)
    elif dataset == 'prokaryotic':
        dataset = DatasetMat(dataset, n_views=3)
    elif dataset == 'BDGP':
        dataset = BDGP(view=2)
    elif dataset == 'NUSWIDE':
        dataset = NUSWIDE(view=2)

    else:
        raise NotImplementedError

    dims = dataset.view_dims
    view = dataset.n_views
    class_num = dataset.n_clusters
    data_size = dataset.data_size

    return dataset, dims, view, class_num, data_size
