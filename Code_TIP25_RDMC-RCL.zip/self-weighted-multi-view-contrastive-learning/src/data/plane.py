import os
os.environ["OMP_NUM_THREADS"] = '1'

import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.manifold import TSNE
from dataloader import ExperimentDataset
from sklearn.cluster import KMeans
import numpy as np
from sklearn.metrics import confusion_matrix
from scipy.optimize import linear_sum_assignment


def best_map(label, pred, n_clusters):
    cmat = confusion_matrix(label, pred)
    ri, ci = linear_sum_assignment(-cmat)
    ordered = cmat[np.ix_(ri, ci)]

    # confusion[i, j] = np.sum(np.logical_and(idx2i, idx2j))

    new_pred = np.zeros(pred.shape)
    for i in ri:
        new_pred[pred == ci[i]] = i
    return new_pred


def run_k_means(fea, n_clusters, n_views=None):
    cluster_result = []
    k_means = KMeans(n_clusters, n_init=100, random_state=100)
    if n_views is not None:
        for v in range(n_views):
            y_pred = k_means.fit_predict(fea[v])
            cluster_result.append(y_pred)

    return cluster_result


def t_sne(x, hue, ax, title=None, legend_title=None, cmap="tab10", legend_loc=1, **kwargs):
    x = TSNE(n_components=2).fit_transform(x)
    pl = sns.scatterplot(x=x[:, 0], y=x[:, 1], hue=hue, ax=ax, legend="full", palette=cmap, **kwargs)
    leg = pl.get_legend()
    leg._loc = legend_loc
    if title is not None:
        ax.set_title(title)
    if legend_title is not None:
        leg.set_title(legend_title)


def main():
    # 加载数据
    name = "Caltech-3V"
    dataset = ExperimentDataset(name, None)
    n_views = dataset.n_views
    n_clusters = dataset.n_clusters
    labels = np.squeeze(dataset.labels)
    views = dataset.data_views
    data_size = dataset.data_size

    # 每个视角做k-means
    local_clustering = run_k_means(views, n_clusters, n_views)
    for v in range(1, n_views):
        local_clustering[v] = best_map(local_clustering[0], local_clustering[v], n_clusters)

    proto_idx = np.where(np.all(local_clustering[0][np.newaxis, :] == local_clustering, axis=0))[0]
    proto2cluster = local_clustering[0][proto_idx]

    proto_label = []
    for v in range(n_views):
        l = np.zeros_like(labels)
        l[proto_idx] = proto2cluster
        not_proto_idx = np.array(list(set(range(data_size)) - set(proto_idx)))
        l[not_proto_idx] = labels.max() + 1
        proto_label.append(l)

    # t-sne画图
    fig, ax = plt.subplots(n_views, 3, figsize=(20, 10))
    for v in range(n_views):
        t_sne(x=views[v], hue=labels, ax=ax[v][0], title="true", legend_title="cluster", hue_order=sorted(list(set(labels))), cmap="tab10")
        t_sne(x=views[v], hue=local_clustering[v], ax=ax[v][1], title="pred", legend_title="cluster",
              hue_order=sorted(list(set(labels))), cmap="hls")
        t_sne(x=views[v], hue=proto_label[v], ax=ax[v][2], title="pred", legend_title="cluster",
              hue_order=sorted(list(set(labels))), cmap="hls")

    plt.show()


if __name__ == '__main__':
    main()


