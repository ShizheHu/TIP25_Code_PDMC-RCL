import torch
import torch.nn as nn
import math
from kernel import vector_kernel, cdist


class InstanceLoss(nn.Module):
    def __init__(self, batch_size, n_clusters, temperature, device):
        super(InstanceLoss, self).__init__()
        self.batch_size = batch_size
        self.n_clusters = n_clusters
        self.temperature = temperature
        self.device = device

        self.mask = self.mask_correlated_samples(batch_size)
        self.negative_samples_ratio = 0.5
        self.criterion = nn.CrossEntropyLoss(reduction="sum")

    def _get_negative(self, final_pred):
        pos_idx = torch.arange(0, 2 * self.batch_size).long()

        pseudo_label = final_pred.detach().argmax(dim=1)
        pseudo_label = torch.cat(2 * [pseudo_label], dim=0)

        eye = torch.eye(self.n_clusters, device=self.device)
        weights = (1 - eye[pseudo_label])[:, pseudo_label[pos_idx]].T
        n_negative = int(self.negative_samples_ratio * pseudo_label.size(0))
        # 0.5的采样率基本最好了
        # n_negative = torch.sum(weights, dim=1).min().long()
        neg_idx = torch.multinomial(weights, n_negative, replacement=True)

        return pos_idx, neg_idx

    def mask_correlated_samples(self, batch_size):
        N = 2 * batch_size
        mask = torch.ones((N, N))
        mask = mask.fill_diagonal_(0)
        for i in range(batch_size):
            mask[i, batch_size + i] = 0
            mask[batch_size + i, i] = 0
        mask = mask.bool()
        return mask

    def forward(self, z_i, z_j, final_pred=None):
        N = 2 * self.batch_size
        z = torch.cat((z_i, z_j), dim=0)

        sim = torch.matmul(z, z.T) / self.temperature
        sim_i_j = torch.diag(sim, self.batch_size)
        sim_j_i = torch.diag(sim, -self.batch_size)

        positive_samples = torch.cat((sim_i_j, sim_j_i), dim=0).reshape(N, 1)
        if final_pred is None:
            negative_samples = sim[self.mask].reshape(N, -1)
        else:
            pos_idx, neg_idx = self._get_negative(final_pred)
            negative_samples = sim[pos_idx.reshape(-1, 1), neg_idx].reshape(N, -1)

        labels = torch.zeros(N).to(self.device).long()
        logits = torch.cat((positive_samples, negative_samples), dim=1)
        loss = self.criterion(logits, labels)
        loss /= N

        return loss


class ClusterLoss(nn.Module):
    def __init__(self, class_num, temperature, device):
        super(ClusterLoss, self).__init__()
        self.class_num = class_num
        self.temperature = temperature
        self.device = device

        self.mask = self.mask_correlated_clusters()
        self.criterion = nn.CrossEntropyLoss(reduction="sum")
        self.similarity_f = nn.CosineSimilarity(dim=2)

    def mask_correlated_clusters(self):
        N = 2 * self.class_num
        mask = torch.ones((N, N))
        mask = mask.fill_diagonal_(0)
        for i in range(self.class_num):
            mask[i, self.class_num + i] = 0
            mask[self.class_num + i, i] = 0
        mask = mask.bool()
        return mask

    def forward(self, c_i, c_j):
        p_i = c_i.sum(0).view(-1)
        p_i /= p_i.sum()
        ne_i = math.log(p_i.size(0)) + (p_i * torch.log(p_i)).sum()
        p_j = c_j.sum(0).view(-1)
        p_j /= p_j.sum()
        ne_j = math.log(p_j.size(0)) + (p_j * torch.log(p_j)).sum()
        ne_loss = ne_i + ne_j

        c_i = c_i.t()
        c_j = c_j.t()
        N = 2 * self.class_num
        c = torch.cat((c_i, c_j), dim=0)

        sim = self.similarity_f(c.unsqueeze(1), c.unsqueeze(0)) / self.temperature
        sim_i_j = torch.diag(sim, self.class_num)
        sim_j_i = torch.diag(sim, -self.class_num)

        positive_clusters = torch.cat((sim_i_j, sim_j_i), dim=0).reshape(N, 1)
        negative_clusters = sim[self.mask].reshape(N, -1)

        labels = torch.zeros(N).to(positive_clusters.device).long()
        logits = torch.cat((positive_clusters, negative_clusters), dim=1)
        loss = self.criterion(logits, labels)
        loss /= N

        return loss + ne_loss


class DDCLoss(nn.Module):
    def __init__(self, n_clusters, sigma, device):
        super(DDCLoss, self).__init__()
        self.n_clusters = n_clusters
        self.eye = torch.eye(n_clusters, device=device)
        self.sigma = sigma
        self.eps = 1e-9

    def _triu(self, x):
        return torch.sum(torch.triu(x, diagonal=1))

    def _at_least_epsilon(self, x, eps=None):
        if eps is None:
            eps = self.eps
        return torch.where(x < eps, x.new_tensor(eps), x)

    def _d_cs(self, ddc_hidden, ddc_out):
        k_mat = vector_kernel(ddc_hidden, self.sigma)
        nom = torch.t(ddc_out) @ k_mat @ ddc_out

        dnom_squared = torch.unsqueeze(torch.diagonal(nom), -1) @ torch.unsqueeze(torch.diagonal(nom), 0)

        nom = self._at_least_epsilon(nom)
        dnom_squared = self._at_least_epsilon(dnom_squared, eps=self.eps ** 2)

        d = 2 / (self.n_clusters * (self.n_clusters - 1)) * self._triu(nom / torch.sqrt(dnom_squared))
        return d

    def forward(self, ddc_hidden, ddc_out):
        batch_size = ddc_out.size(0)

        ddc_1 = self._d_cs(ddc_hidden, ddc_out)
        ddc_2 = 2 / (batch_size * (batch_size - 1)) * self._triu(ddc_out @ torch.t(ddc_out))

        mat = torch.exp(-cdist(ddc_out, self.eye))
        ddc_3 = self._d_cs(ddc_hidden, mat)

        ddc_loss = ddc_1 + ddc_2 + ddc_3
        return ddc_loss

