from sklearn.metrics import v_measure_score, adjusted_rand_score, accuracy_score, confusion_matrix
from scipy.optimize import linear_sum_assignment
from torch.utils.data import DataLoader
import numpy as np
import torch
from matplotlib import pyplot as plt
from sklearn.manifold import TSNE


def cluster_acc(y_true, y_pred):
    y_true = y_true.astype(np.int64)
    assert y_pred.size == y_true.size
    D = max(y_pred.max(), y_true.max()) + 1
    w = np.zeros((D, D), dtype=np.int64)
    for i in range(y_pred.size):
        w[y_pred[i], y_true[i]] += 1
    u = linear_sum_assignment(w.max() - w)
    ind = np.concatenate([u[0].reshape(u[0].shape[0], 1), u[1].reshape([u[0].shape[0], 1])], axis=1)
    return sum([w[i, j] for i, j in ind]) * 1.0 / y_pred.size


def purity(y_true, y_pred):
    y_voted_labels = np.zeros(y_true.shape)
    labels = np.unique(y_true)
    ordered_labels = np.arange(labels.shape[0])
    for k in range(labels.shape[0]):
        y_true[y_true == labels[k]] = ordered_labels[k]
    labels = np.unique(y_true)
    bins = np.concatenate((labels, [np.max(labels) + 1]), axis=0)

    for cluster in np.unique(y_pred):
        hist, _ = np.histogram(y_true[y_pred == cluster], bins=bins)
        winner = np.argmax(hist)
        y_voted_labels[y_pred == cluster] = winner

    return accuracy_score(y_true, y_voted_labels)


def evaluate(label, pred):
    nmi = v_measure_score(label, pred)
    ari = adjusted_rand_score(label, pred)
    acc = cluster_acc(label, pred)
    pur = purity(label, pred)
    return nmi, ari, acc, pur


def valid(run, model, device, dataset, view, data_size, epoch=None):
    eval_loader = DataLoader(
        dataset,
        batch_size=data_size,
        shuffle=False,
    )
    for batch, (x, y, _) in enumerate(eval_loader):
        for v in range(view):
            x[v] = x[v].to(device)

    labels = y.detach().data.numpy().squeeze()

    # get pred
    model.eval()
    with torch.no_grad():
        _, _, final_output, _ = model(x)
    model.train()

    # Clustering results
    pred = final_output.cpu().detach().numpy()
    pred = np.argmax(pred, axis=1)
    pred = pred.squeeze()
    nmi, ari, acc, pur = evaluate(labels, pred)

    # 混淆矩阵
    # cmat = confusion_matrix(labels, pred)
    # ri, ci = linear_sum_assignment(-cmat)
    # ordered = cmat[np.ix_(ri, ci)]

    if epoch is not None:
        # print('Confusion Matrix:')
        # print(ordered)
        print('Epoch {}'.format(epoch),
              'The clustering performance: ACC = {:.4f} NMI = {:.4f} ARI = {:.4f} PUR={:.4f}'.format(acc, nmi, ari,
                                                                                                     pur))
        # if epoch in {0, 5,15,24}:
        #     tsne = TSNE(n_components=2, random_state=42)
        #     tsne_results = tsne.fit_transform(final_output.cpu().detach().numpy())
        #
        #     plt.figure(figsize=(8, 6))
        #     scatter = plt.scatter(tsne_results[:, 0], tsne_results[:, 1], c=labels, cmap='viridis', alpha=0.6)
        #     plt.colorbar(scatter, label='True Labels')
        #     plt.title(f't-SNE visualization at run {run}epoch {epoch}')
        #     plt.xlabel('t-SNE 1')
        #     plt.ylabel('t-SNE 2')
        #     plt.show()
    else:
        # print('Confusion Matrix:')
        # print(ordered)
        print(
            'The clustering performance: ACC = {:.4f} NMI = {:.4f} ARI = {:.4f} PUR={:.4f}'.format(acc, nmi, ari, pur))

    return acc, nmi, pur
