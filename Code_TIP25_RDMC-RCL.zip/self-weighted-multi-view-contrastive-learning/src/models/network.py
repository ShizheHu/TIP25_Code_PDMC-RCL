import torch
import torch.nn as nn
import torch.nn.functional as F

def he_init_weights(module):
    if isinstance(module, (nn.Conv2d, nn.Linear)):
        nn.init.kaiming_normal_(module.weight)


class Encoder(nn.Module):
    def __init__(self, dim_in, dim_out):
        super(Encoder, self).__init__()
        self.encoder = nn.Sequential(
            nn.Linear(dim_in, 512),
            nn.ReLU(),
            nn.Linear(512, 512),
            nn.ReLU(),
            nn.Linear(512, dim_out),
            nn.ReLU(),
        )

    def forward(self, x):
        return self.encoder(x)


class DDC(nn.Module):
    def __init__(self, input_dim, hidden_dim, n_clusters):
        super().__init__()

        self.hidden = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.BatchNorm1d(hidden_dim),
            nn.ReLU(),
        )
        self.output = nn.Sequential(
            nn.Linear(hidden_dim, n_clusters),
            nn.Softmax(dim=1)
        )

    def forward(self, x):
        hidden = self.hidden(x)
        output = self.output(hidden)
        return output, hidden


class Network(nn.Module):

    def __init__(self, n_views, n_clusters, dims_in, fea_dim, use_pro=False):
        super(Network, self).__init__()
        self.n_views = n_views
        self.n_clusters = n_clusters

        self.encoders = [Encoder(dim_in, fea_dim) for dim_in in dims_in]
        self.encoders = nn.ModuleList(self.encoders)

        # 特征融合权重
        self.fusion_weights = nn.Parameter(torch.full((n_views,), 1 / n_views), requires_grad=True)

        # 固定，CoMVC中的hidden的dim_out为100
        self.ddc = DDC(input_dim=fea_dim, hidden_dim=100, n_clusters=n_clusters)

        if use_pro:
            self.instance_projector = nn.Sequential(
                nn.Linear(fea_dim, fea_dim),
                nn.ReLU(),
                nn.Linear(fea_dim, 128),
            )
        else:
            self.instance_projector = nn.Identity()
            # 何的初始化方式
            self.apply(he_init_weights) 

    def _weighted_fused_feature(self, high_feature, norm_weights=True):
        # if norm_weights:
        #     weights = nn.functional.softmax(self.fusion_weights, dim=0)
        # fused_feature = torch.sum(weights[None, None, :] * torch.stack(high_feature, dim=-1), dim=-1)
        weights = nn.functional.softmax(self.fusion_weights, dim=0) if norm_weights else self.fusion_weights
        fused_feature = torch.sum(weights[None, None, :] * torch.stack(high_feature, dim=-1), dim=-1)

        return fused_feature

    def forward(self, x):
        instance = []
        local_output = []
        high_feature = []
        for i in range(self.n_views):
            z = self.encoders[i](x[i])
            high_feature.append(z)
            instance.append(self.instance_projector(z))
            local_pred, _ = self.ddc(z)
            local_output.append(local_pred)

        # 特征融合
        fused_feature = self._weighted_fused_feature(high_feature)
        # 融合特征过ddc
        final_output, ddc_hidden = self.ddc(fused_feature)

        return instance, local_output, final_output, ddc_hidden

