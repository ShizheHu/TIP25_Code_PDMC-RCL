import argparse
import torch
import torch.nn as nn
import numpy as np
import torchvision
from sklearn.manifold import TSNE
from network import Network
from loss import InstanceLoss, ClusterLoss, DDCLoss
from data.dataloader import load_data
from metric import valid
from sklearn.metrics import normalized_mutual_info_score
from matplotlib import pyplot as plt

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# Synthetic3d
# prokaryotic
# Event8
# Caltech-3V
# ccv
# DHA
# soccer
# Flowers17
DataName = "nus22"
parser = argparse.ArgumentParser(description='train')
parser.add_argument('--data_name', default=DataName)
parser.add_argument('--batch_size', default=128, type=int)  # 128 固定住
parser.add_argument('--instance_elin', default=True, type=bool)
parser.add_argument("--weighting_method", default="MMD", type=str)
parser.add_argument("--instance_temperature", default=0.1, type=float)  # 0.1 固定住
parser.add_argument("--cluster_temperature", default=1.0, type=float)
parser.add_argument("--instance_hyper_parameters", default=1.0, type=float)
parser.add_argument("--cluster_hyper_parameters", default=1.0, type=float)
parser.add_argument("--learning_rate", default=0.0003, type=float)
parser.add_argument("--weight_decay", default=0., type=float)
parser.add_argument("--runs", default=10, type=int)
parser.add_argument("--epochs", default=200, type=int)
parser.add_argument('--seed', default=0, type=int)
parser.add_argument('--feature_dim', default=256, type=int)
parser.add_argument('--ddc_sigma', default=0.15, type=float)

args = parser.parse_args()

if args.data_name == 'Caltech-6V':
    #args.epochs = 5
    args.instance_hyper_parameters = 1.0
    args.cluster_hyper_parameters = 1.0

if args.data_name == 'NUSWIDE-OBJECT':
    args.epochs = 50
    args.instance_hyper_parameters = 1.0
    args.cluster_hyper_parameters = 1.0

if args.data_name == 'BDGP':
    args.epochs = 25
    args.instance_hyper_parameters = 1.0
    args.cluster_hyper_parameters = 1.0

def main():
    # 加载数据集
    dataset, view_dims, n_views, n_clusters, data_size = load_data(args.data_name)

    train_loader = torch.utils.data.DataLoader(
        dataset,
        batch_size=args.batch_size,
        shuffle=True,
        drop_last=True
    )

    # 固定seed
    set_seed(args.seed)

    accs = []
    nmis = []
    purs = []

    print('========  Weighted Contrastive Learning  ========')

    # start run for
    for run in range(args.runs):
        print(f"ROUND:{run + 1}")

        best_acc, best_nmi, best_pur = 0.0, 0.0, 0.0

        # model, optimizer  每一轮重新构造网络
        model = Network(n_views, n_clusters, view_dims, args.feature_dim)
        # model = Network(n_views, n_clusters, view_dims, args.feature_dim, use_pro=True)
        # print(model)
        model.to(device)

        optimizer = torch.optim.Adam(model.parameters(), lr=args.learning_rate, weight_decay=args.weight_decay)
        instance_loss = InstanceLoss(args.batch_size, n_clusters, args.instance_temperature, device)
        cluster_loss = ClusterLoss(n_clusters, args.cluster_temperature, device)
        ddc_loss = DDCLoss(n_clusters, args.ddc_sigma, device)

        plot_loss = []
        plot_acc = []
        plot_nmi = []

        # start epoch for

        for epoch in range(args.epochs):
            epoch_loss = 0

            for batch, (data, _, _) in enumerate(train_loader):
                for v in range(n_views):
                    data[v] = data[v].to(device)

                instance, local_pred, ddc_out, ddc_hidden = model(data)

                w_sub_clu, w_sub_ins, sub_ddc = 0, 0, 0
                with torch.no_grad():
                    ins_weight = compute_cluster_relation(local_pred, n_views)
                    clu_weight = compute_instance_relation(instance, n_views, weighting_method=args.weighting_method)

                for i in range(n_views):
                    for j in range(i + 1, n_views):
                        if args.instance_elin:
                            w_sub_ins += ins_weight[i][j] * instance_loss(instance[i], instance[j], ddc_out)
                        else:
                            w_sub_ins += ins_weight[i][j] * instance_loss(instance[i], instance[j])
                        w_sub_clu += clu_weight[i][j] * cluster_loss(local_pred[i], local_pred[j])

                sub_ddc = ddc_loss(ddc_hidden, ddc_out)

                loss = args.instance_hyper_parameters * w_sub_ins + args.cluster_hyper_parameters * w_sub_clu + sub_ddc

                optimizer.zero_grad()
                loss.backward()
                optimizer.step()

                epoch_loss += loss.item()
            print(f'Epoch {epoch}: Loss = {epoch_loss / len(train_loader):.6f}')

            acc, nmi, pur = valid(run, model, device, dataset, n_views, data_size, epoch)
            if acc > best_acc:
                best_acc, best_nmi, best_pur = acc, nmi, pur
                state = model.state_dict()

            # 添加画图信息
            plot_loss.append(epoch_loss / len(train_loader))
            plot_acc.append(acc)
            plot_nmi.append(nmi)
        plot(plot_loss, plot_acc, plot_nmi, best_acc, best_nmi)


        print("The best clustering performance: ACC = {:.4f} NMI = {:.4f} PUR = {:.4f}".format(best_acc, best_nmi,
                                                                                               best_pur))
        accs.append(best_acc)
        nmis.append(best_nmi)
        purs.append(best_pur)

    # end run for

    print("All of the ACC: {}".format(accs))
    print("All of the NMI: {}".format(nmis))

    # save_result(accs, nmis)



def set_seed(seed):
    print("seed is {}".format(seed))
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True


def compute_instance_relation(instance, n_views, weighting_method="MMD"):
    w = torch.zeros((n_views, n_views), device=device)
    for i in range(n_views):
        for j in range(i + 1, n_views):
            if weighting_method == "MMD":
                w_ij = MMD(instance[i], instance[j])
            elif weighting_method == "JSD":
                w_ij = JSD(instance[i], instance[j])

            w[i][j] = torch.exp(-w_ij)
    w = w / torch.sum(w)
    return w


def MMD(distribution_p, distribution_q, get_norm=True):
    n = distribution_p.size(0)

    if get_norm:
        p = nn.functional.normalize(distribution_p)
        q = nn.functional.normalize(distribution_q)
    else:
        p = distribution_p
        q = distribution_q

    p_sim = torch.matmul(p, p.t())
    q_sim = torch.matmul(q, q.t())
    pq_sim = torch.matmul(p, q.t())

    mmd = (torch.sum(p_sim) + torch.sum(q_sim) - 2 * torch.sum(pq_sim)) / (n * n)
    return mmd


def JSD(distribution_p, distribution_q, get_softmax=True):
    KL = torch.nn.KLDivLoss(reduction="batchmean")
    if get_softmax:
        p = nn.functional.softmax(distribution_p, dim=1)
        q = nn.functional.softmax(distribution_q, dim=1)
    else:
        p = distribution_p
        q = distribution_q
    log = ((p + q) / 2).log()
    jsd = (KL(log, p) + KL(log, q)) / 2
    return jsd


def compute_cluster_relation(local, n_views):
    w = torch.zeros((n_views, n_views), device=device)
    for i in range(n_views):
        for j in range(i + 1, n_views):
            i_pred = local[i].detach().argmax(dim=1)
            i_pred = i_pred.cpu().detach().numpy()

            j_pred = local[j].detach().argmax(dim=1)
            j_pred = j_pred.cpu().detach().numpy()

            w_ij = normalized_mutual_info_score(i_pred, j_pred)
            w[i][j] = torch.exp(torch.tensor(w_ij))

    w = w / torch.sum(w)
    return w

def plot(loss, acc, nmi, best_acc, best_nmi):
    # y_loss = loss  # loss值，即y轴
    # x = range(len(y_loss))  # loss的数量，即x轴
    #
    # fig, ax_acc = plt.subplots()
    # ax_loss = ax_acc.twinx()
    #
    #
    # ax_acc.plot(x, acc, linewidth=2, linestyle="solid", label="acc", color='blue')
    # ax_acc.set_xlabel('Epochs')
    # ax_acc.set_ylabel('ACC')
    # ax_acc.set_title('Lambda: {:.2f}, Gama: {:.2f}, Final acc: {:.4f}'.format(args.instance_hyper_parameters, args.cluster_hyper_parameters, best_acc))
    #
    # ax_loss.plot(x, loss, linewidth=2, linestyle="solid", label="loss", color='red')
    # ax_loss.set_ylabel('Loss')
    #
    # plt.show()

    y_loss = loss  # loss值，即y轴
    x = range(len(y_loss))  # loss的数量，即x轴

    fig, ax_acc = plt.subplots()
    ax_loss = ax_acc.twinx()

    # 绘制acc曲线
    acc_line, = ax_acc.plot(x, acc, linewidth=2, linestyle="solid", label="acc", color='blue')
    ax_acc.set_xlabel('Epochs')
    ax_acc.set_ylabel('ACC and NMI')

    # 绘制nmi曲线
    nmi_line, = ax_acc.plot(x, nmi, linewidth=2, linestyle="dashed", label="nmi", color='green')

    ax_acc.set_title('seed:{:.2f},acc: {:.4f},nmi: {:.4f}'.format(args.seed, best_acc, best_nmi))
    # ax_acc.set_title('Lambda: {:.2f}, Gama: {:.2f}, Final acc: {:.4f}'.format(args.instance_hyper_parameters,
    # args.cluster_hyper_parameters, best_acc))

    # 绘制loss曲线
    loss_line, = ax_loss.plot(x, loss, linewidth=2, linestyle="solid", label="loss", color='red')
    ax_loss.set_ylabel('Loss')
        # ax_acc.set_ylim(0, 1)
    # 创建一个包含所有标签的图例
    lines = [acc_line, nmi_line, loss_line]
    labels = [line.get_label() for line in lines]
    ax_loss.legend(lines, labels, loc='center right')

    plt.show()


def save_result(acc, nmi):
    txt_path = "../../results/{}+lambda{}+gama{}.txt".format(args.data_name, args.instance_hyper_parameters,
                                                             args.cluster_hyper_parameters)

    runs = len(acc)
    with open(txt_path, 'w+') as f:
        f.write('runs = {}'.format(runs))
        f.write('\nlambda = {}'.format(args.instance_hyper_parameters))
        f.write('\ngama = {}'.format(args.cluster_hyper_parameters))

        f.write('\nAll of the ACC: ')
        for i in range(runs):
            f.write('{:.4f}  '.format(acc[i]))
        f.write('\nAll of the NMI: ')
        for j in range(runs):
            f.write('{:.4f}  '.format(nmi[j]))


if __name__ == '__main__':
    main()

